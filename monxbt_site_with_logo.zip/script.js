// script.js — minimal interactivity
function handleContact(e){
  e.preventDefault();
  const form = e.target;
  const name = form.name.value.trim();
  const email = form.email.value.trim();
  const message = form.message.value.trim();
  // For a static site, we just show a success message. Integrate with serverless endpoint to send mails.
  alert('Thanks, ' + name + '! Your message was received (demo).');
  form.reset();
  return false;
}

document.getElementById('deployBtn')?.addEventListener('click', function(){
  window.location.href = '#contact';
});
