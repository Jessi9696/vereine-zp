# MONXBT — Static Website

This repository contains a ready-to-deploy static website for **MONXBT**.

Project description:
> MONXBT is first Autonomous agent, tokenized onchain strategies that work for you. Powered by Monad.

## Files
- `index.html` — Main HTML page
- `styles.css` — Styling (dark modern theme)
- `script.js` — Small JS for simple interactions
- `logo.svg` — Placeholder logo (you should replace this with your real logo)
- `README.md` — This file

## Quick local preview
1. Place your `logo.svg` in the project root (replace placeholder).
2. Run a local static server (Python 3.x):
   ```bash
   cd monxbt_site
   python -m http.server 3000
   # then open http://localhost:3000 in your browser
   ```

## Deploy to Vercel (recommended for static sites)
1. Install Vercel CLI: `npm i -g vercel`
2. From this project directory:
   ```bash
   vercel login
   vercel
   ```
3. Accept defaults or configure project name `MONXBT`. Vercel will build and publish the site and give you a public URL.

## Deploy to GitHub Pages
1. Push this folder to a Git repository.
2. Create a branch `gh-pages` or use GitHub Pages settings to serve from `main` or `gh-pages`.
3. Enable GitHub Pages in repository settings.

## Notes / Next steps
- Replace `logo.svg` with your official logo (ensure transparent background).
- Integrate a contact form backend (e.g., Formspree, Netlify forms, or a serverless function) to receive messages.
- Add analytics, SEO meta tags, and social preview images.
